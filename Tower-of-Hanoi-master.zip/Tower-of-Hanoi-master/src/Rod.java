
public class Rod {

	public Rod() {
		// TODO Auto-generated constructor stub
	}

	Stack s = new Stack();

}
